## What it does

Allows using KSP action groups for some game functions that don't support that.

 
## How to install

Unzip the contents of "GameData" to your GameData folder, same as with most mods. (Note, includes ModuleManager.)

